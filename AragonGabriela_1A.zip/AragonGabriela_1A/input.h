#ifndef INPUT_H_INCLUDED
#define INPUT_H_INCLUDED

int esNumerico(char[]);
char validarMenu(char);
int validarFloat(char[]);


#endif

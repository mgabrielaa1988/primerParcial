#ifndef INFORMES_H_INCLUDED
#define INFORMES_H_INCLUDED

void informar(eProductos[],int);
void informarA(eProductos[],int);
void informarB(eProductos[],int);
void informarC(eProductos[],int);
void informarD(eProductos[],int);
void listar(eProductos[],eProveedores[],int,int);
void listarA(eProductos[],int);
void listarB(eProductos[],int);
void listarC(eProductos[],int);
void listarD(eProductos[],int);
void listarE(eProductos[],int);
void listarF(eProveedores[],eProductos[],int,int);
void listarG(eProveedores[],eProductos[],int,int);
void listarH(eProveedores[],eProductos[],int,int);
void listarI(eProveedores[],eProductos[],int,int);
void listarJ(eProveedores[],eProductos[],int,int);
void listarK(eProveedores[],eProductos[],int,int);
void listarL(eProveedores[],eProductos[],int,int);

#endif
